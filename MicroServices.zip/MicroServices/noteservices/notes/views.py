from django.http import HttpResponse
from .models import Notes
from .serializers import NotesSerializer

from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status

import requests
'''
    Technical test for PLAYVOX
    Author: Mario Fernando Espinosa
    API REST Framework Notes
    February 2020
'''

#check if the user id exits. Connect to microservice user
def check_user(iduser):
    url = 'http://userservices:8000/v1/usercheck/{}'.format(iduser)
    response = requests.get(url)
    data = response.json()
    return data

#API NOTES
class NotesView(APIView):

    #Get all notes from a specific user
    def get(self, request, iduser):
        #check if the user id exits. Connect to microservice user
        data = check_user(int(iduser))
        if (data == "error"):
            return Response("error", status=status.HTTP_400_BAD_REQUEST)
        notes = Notes.objects.filter(iduser=iduser)
        serializer = NotesSerializer(notes, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    #Create a new Note
    def post(self, request, format=None):
        serializer = NotesSerializer(data=request.data)
        #check if the user id exits. Connect to microservice user
        data = check_user(int(request.data['iduser']))
        if (data == "error"):
            return Response("error", status=status.HTTP_400_BAD_REQUEST)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
