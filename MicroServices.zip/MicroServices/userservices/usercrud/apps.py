from django.apps import AppConfig


class UsercrudConfig(AppConfig):
    name = 'usercrud'
